# El Baratón ReactJS frontend test for Rappi

Prueba técnica para el cargo frontend web developer

[Live Demo](  ahora pongo la url   )

## Instalación y a disfrutar

Se debe contar con nodeJS 8 o superior instalado, npm para el manejo y administración de paquetes, conocimientos en terminal, responsive web design, desarrollo web, entre otras coas.

### PRIMER PASO

Abrir la carpeta de la web app en el terminal y ejecutar el comando `npm install`

### SEGUNDO PASO

Lanzar la web app con el comando `npm start`


## Implementación
Las interfaces se implementaron con `ReactJS` y clases css responsive de `Bootstrap 3.3.7`.
